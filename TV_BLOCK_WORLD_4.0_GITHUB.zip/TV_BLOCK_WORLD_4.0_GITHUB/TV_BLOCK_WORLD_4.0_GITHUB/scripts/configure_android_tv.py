from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
if not p.exists():
    raise SystemExit('找不到 AndroidManifest.xml；Capacitor Android 项目可能没有生成。')
s = p.read_text(encoding='utf-8')
# Android TV capability is optional so the same APK can also install on phones/tablets.
feature = '<uses-feature android:name="android.software.leanback" android:required="false" />'
if 'android.software.leanback' not in s:
    s = s.replace('<application', feature + '\n    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n    <application', 1)
# Add TV launcher category to the existing MAIN/LAUNCHER activity filter.
needle = '<category android:name="android.intent.category.LAUNCHER" />'
if needle in s and 'android.intent.category.LEANBACK_LAUNCHER' not in s:
    s = s.replace(needle, needle + '\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />', 1)
# Lock to landscape, appropriate for TV gameplay.
if 'android:screenOrientation=' not in s:
    s = s.replace('android:name=".MainActivity"', 'android:name=".MainActivity" android:screenOrientation="landscape"', 1)
p.write_text(s, encoding='utf-8')
print('Android TV manifest configured.')
