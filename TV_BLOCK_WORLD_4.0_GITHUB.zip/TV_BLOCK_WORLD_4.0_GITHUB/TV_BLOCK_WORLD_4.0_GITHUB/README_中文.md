# TV BLOCK WORLD 4.0 — GitHub 自动打包 APK

本项目把现有离线 HTML 游戏封装为 Android 应用，并通过 GitHub Actions 云端自动生成 APK。无需在电脑安装 Android Studio，也无需使用命令行。

## 用 GitHub 网页操作

1. 登录 GitHub，点击右上角 **+ → New repository**。
2. 仓库名称填写 `TV-BLOCK-WORLD`，选择 **Public** 或 **Private**，点击 **Create repository**。
3. 在仓库页面选择 **Add file → Upload files**。
4. 解压本 ZIP，把里面所有文件和文件夹（包括 `.github`、`scripts`、`www`）拖入上传区域。注意：必须上传文件夹内部的内容，不能只上传外层 ZIP。
5. 在页面底部点击 **Commit changes**。
6. 打开仓库上方 **Actions**，选择 **Build TV BLOCK WORLD APK**。
7. 如果没有自动运行，点击 **Run workflow → Run workflow**。
8. 等待任务显示绿色勾号，点进本次运行页面，在 **Artifacts** 区域下载 `TV-BLOCK-WORLD-4.0-Android-APK`。
9. 解压下载的 artifact ZIP，里面的 `app-debug.apk` 就是安装包。

## 安装到 Android TV / Google TV

把 `app-debug.apk` 复制到电视或 U 盘，在电视上用文件管理器打开 APK 安装。若电视提示禁止安装未知来源应用，需要在系统设置中允许该文件管理器安装未知应用。

## 注意

- 此构建是未签名的调试 APK（debug APK），可用于个人测试和侧载安装，不是 Google Play 发布版。
- GitHub Actions 首次构建会在线下载 Android/Capacitor 构建依赖，因此需要 GitHub Actions 可用。
- 游戏本体仍是离线 HTML/WebGL；首次安装后不需要网站服务器。
- 遥控器按键映射受电视厂商和系统版本影响，必须在目标电视实测。若按键无法被 WebView 传递，后续需要原生 Android 按键桥接。
